<?php

namespace APP\Models;

use CodeIgniter\Model;

class HomeModel extends Model
{
    // Método genérico para obtener registros de una tabla
    private function getTableData($tableName)
    {
        $query = $this->db->table($tableName)->get();
        $result = $query->getResult();

        // Retornar datos si existen registros
        return count($result) >= 1 ? $result : NULL;
    }

    // Método para productos
    public function products_lst()
    {
        return $this->getTableData('products');
    }

    // Método para usuarios
    public function users_lst()
    {
        return $this->getTableData('users');
    }

    // Método para insertar un producto
    public function insert_product($data)
    {
        return $this->db->table('products')->insert($data);
    }

    // Método para actualizar un producto
    public function update_product($id, $data)
    {
        return $this->db->table('products')->where('id', $id)->update($data);
    }

    // Método para eliminar un producto
    public function delete_product($id)
    {
        return $this->db->table('products')->where('id', $id)->delete();
    }
}

