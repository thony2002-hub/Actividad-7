<?php

use CodeIgniter\Router\RouteCollection;

/**
 * @var RouteCollection $routes
 */
//$routes->get('/', 'Home::index');
//$routes->get('/hola', 'Home::index');
// Rutas para operaciones CRUD

// Obtener todos los productos
$routes->get('/', 'Home::index'); 

// Insertar un producto
$routes->post('/products', 'Home::insert_product'); 

// Modificar un producto
$routes->put('/products(:num)', 'Home::update_product/$1'); 

// Eliminar un producto
$routes->delete('/products(:num)', 'Home::delete_product/$1'); 
