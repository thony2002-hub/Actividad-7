<?php

namespace App\Controllers;

class Home extends BaseController
{
    public $modelHome = NULL;

    public function __construct()
    {
        $this->modelHome = model("HomeModel");
    }
    
    public function index()
    {
        // Obtener datos de productos y usuarios
        $products = $this->modelHome->products_lst();
        $users = $this->modelHome->users_lst();

        // Crear un array con ambos resultados
        $data = [
            'products' => $products,
            'users' => $users
        ];

        // Retornar como JSON
        return $this->response->setJSON($data);
    }

    // Insertar un nuevo producto
    public function insert_product()
    {
        $data = $this->request->getJSON(true);

        if ($this->modelHome->insert_product($data)) {
            return $this->respond(['status' => 'success', 'message' => 'Producto insertado exitosamente'], 200);
        } else {
            return $this->respond(['status' => 'error', 'message' => 'Fallo al insertar producto'], 400);
        }
    }

    // Modificar un producto existente
    public function update_product($id)
    {
        $data = $this->request->getJSON(true);

        if ($this->modelHome->update_product($id, $data)) {
            return $this->respond(['status' => 'success', 'message' => 'Producto actulizado exitosamente'], 200);
        } else {
            return $this->respond(['status' => 'error', 'message' => 'Fallo al actualizar el producto'], 400);
        }
    }

    // Eliminar un producto
    public function delete_product($id)
    {
        if ($this->modelHome->delete_product($id)) {
            return $this->respond(['status' => 'success', 'message' => 'Producto eliminado exitosamente'], 200);
        } else {
            return $this->respond(['status' => 'error', 'message' => 'Fallo al eliminar el producto'], 400);
        }
    }
}
